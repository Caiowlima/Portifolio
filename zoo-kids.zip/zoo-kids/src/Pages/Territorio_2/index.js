import { useState } from 'react';
import { StyleSheet, Text, View, Image, ScrollView, Pressable, Modal, Button, ImageBackground} from 'react-native';
import styles from  './style';
import { useNavigation } from '@react-navigation/native';
export default function Home() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [posicao, setPosicao] = useState(0);

  const [animais, setPlanetas] = useState([
    {nome:"Arara Azul", 
    habitos:"São aves sociais, vivem em bandos e voam longas distâncias em busca de frutas e sementes. São barulhentas e inteligentes." ,
    reproducao:"Formam casais para a vida toda. A fêmea põe de 2 a 4 ovos e os filhotes nascem após cerca de 28 dias.",
    imagem:require('../../../assets/arara.jpg')},
    {nome :"Coruja", 
    habitos:'Animais noturnos, caçam à noite usando visão e audição aguçadas. Vivem sozinhas ou em pares.',
    reproducao:" Fazem ninhos em buracos ou galhos. A fêmea põe de 2 a 6 ovos, incubados por cerca de 30 dias.",
    imagem:require('../../../assets/coruja.jpg')},
    {nome :"Mico", 
    habitos:"Animais diurnos e territoriais, vivem em grupos familiares nas florestas. Alimentam-se de frutas e insetos.",
    reproducao:"A fêmea geralmente dá à luz gêmeos, e todo o grupo ajuda a cuidar dos filhotes.",
    imagem:require('../../../assets/mico.jpg')}
    
    
  ])

  function voltar(){
    setModalVisible(false)
  }

  function abrirModal(p){
    setModalVisible(true);
    setPosicao(p);
  }



  return(
    <View style = {styles.container}>
<View style = {styles.navbar}>
      <View style={styles.voltar}   >
      <Pressable onPress ={() => navigation.navigate('Home')} >
      <Image style={styles.voltar}  source={require('../../../assets/voltar.png')}/>
      </Pressable>
      </View>
      <View>
      <Text style = {styles.menu}> Território 2 </Text>
       </View>
       <View>
      </View>
    
    </View>
    <View style={styles.column}>
       
        
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(0)} >
              <ImageBackground style={styles.elefante} source={require('../../../assets/arara.jpg')}>
                <Text style={styles.negrit}> Arara </Text>
              </ImageBackground>
        </Pressable> 
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(1)} >
        <ImageBackground style={styles.elefante} source={require('../../../assets/coruja.jpg')}>
                <Text style={styles.negrit}> Coruja</Text>
              </ImageBackground>
        </Pressable> 
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(2)} >
        <ImageBackground style={styles.elefante} source={require('../../../assets/mico.jpg')}>
                <Text style={styles.negrit}> Mico </Text>
              </ImageBackground>
        </Pressable> 
      </View>

       <Modal visible={modalVisible} animationType='fade' >
       
        <View style={{justifyContent:'center', alignItems:'center', flex:2, backgroundColor:"#0f0f0f"}}>
        
        <Image source={animais[posicao].imagem} style={{width:"100%", height:"70%"}}/>
        </View>
        <View style={{flex:3, paddingStart:15, backgroundColor:"#0f0f0f"}}>
        <Text style={styles.negrito}>Nome do animal</Text>
        <Text style={styles.normal}>{animais[posicao].nome}</Text>
        <Text style={styles.negrito}>Habitos</Text>
        <Text style={styles.normal}>{animais[posicao].habitos}</Text>
        <Text style={styles.negrito}>Reprodução</Text>
        <Text style={styles.normal}>{animais[posicao].reproducao}</Text>
        </View>
        <View style={{justifyContent:'center', alignItems:'center', backgroundColor:"#0f0f0f"}}>
        <Pressable onPress={()=>voltar()} >
        <Image style={styles.voltar}  source={require('../../../assets/voltar2.png')}/>
        </Pressable>
        </View>
      
      </Modal>
  
    </View>

     


  )  
}