import { useState } from 'react';
import { StyleSheet, Text, View, Image, ScrollView, Pressable, Modal, Button, ImageBackground} from 'react-native';
import styles from  './style';
import { useNavigation } from '@react-navigation/native';
export default function Home() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [posicao, setPosicao] = useState(0);

  const [animais, setPlanetas] = useState([
    {nome :"Mercúrio", 
    habitos:"...",
    reproducao:"...",
    imagem:require('../../../assets/Elefante.jpg')},
    
    
  ])

  function voltar(){
    setModalVisible(false)
  }

  function abrirModal(p){
    setModalVisible(true);
    setPosicao(p);
  }



  return(
    <View style = {styles.container}>
<View style = {styles.navbar}>
      <View style={styles.voltar}   >
      <Pressable onPress ={() => navigation.navigate('Home')} >
      <Image style={styles.voltar}  source={require('../../../assets/voltar.png')}/>
      </Pressable>
      </View>
      <View>
      <Text style = {styles.menu}> Território 5 </Text>
       </View>
       <View>
      </View>
    
    </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(0)} >
              <ImageBackground style={styles.elefante} source={require('../../../assets/Elefante.jpg')}>
                <Text style={styles.negrit}> Elefante </Text>
              </ImageBackground>
        </Pressable> 
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(1)} >
              
                <Text style={styles.negrit}> Onça Pintada </Text>
             
        </Pressable> 
      </View>

       <Modal visible={modalVisible} animationType='fade' >
        <View style={{justifyContent:'center', alignItems:'center', flex:2, backgroundColor:"#000"}}>
        <Text style={{fontSize:30, margin:10}}>Nosso Sistema Solar</Text>
        <Image source={animais[posicao].imagem} style={{width:"70%", height:"90%"}}/>
        </View>
        <View style={{flex:3, paddingStart:15, backgroundColor:"#000"}}>
        <Text style={styles.negrito}>Nome Planeta</Text>
        <Text style={styles.normal}>{animais[posicao].nome}</Text>
        <Text style={styles.negrito}>Hábitos</Text>
        <Text style={styles.normal}>{animais[posicao].duracaoDia}</Text>
        <Text style={styles.negrito}>Reprodução</Text>
        
        </View>
        <View style={{justifyContent:'center', alignItems:'center', backgroundColor:"#000"}}>
        <Button title="voltar" onPress={()=>voltar()} />
        </View>
      </Modal>
    </View>

     


  )  
}