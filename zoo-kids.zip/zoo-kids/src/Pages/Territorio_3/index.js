import { useState } from 'react';
import { StyleSheet, Text, View, Image, ScrollView, Pressable, Modal, Button, ImageBackground} from 'react-native';
import styles from  './style';
import { useNavigation } from '@react-navigation/native';
export default function Home() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [posicao, setPosicao] = useState(0);

  const [animais, setPlanetas] = useState([
    {nome:"Tamandua Bandeira", 
    habitos:"Solitário e terrestre, se alimenta principalmente de formigas e cupins com sua língua longa e pegajosa." ,
    reproducao:"A fêmea dá à luz um único filhote, que anda nas costas da mãe por vários meses.",
    imagem:require('../../../assets/Tamandua.jpg')},
    {nome :"Raposa-do-campo", 
    habitos:'Noturna e solitária, vive em áreas abertas e se alimenta de insetos, frutas e pequenos animais.',
    reproducao:" A época reprodutiva varia, e a gestação dura cerca de 50 dias, com ninhadas de até 5 filhotes",
    imagem:require('../../../assets/raposa.jpg')},
    {nome :"Cachorro do mato", 
    habitos:"Possuem hábitos predominantemente noturnos e crepusculares. Costumam vagar pelos territórios em pares e, quando estão separados, mantêm contato por latidos de alta frequência a longas distâncias",
    reproducao:"Se reproduz o ano todo, principalmente na primavera, e tem uma gestação de 52 a 59 dias. A fêmea dá à luz de 3 a 6 filhotes por parto",
    imagem:require('../../../assets/cachorro.jpg')}
    
    
  ])

  function voltar(){
    setModalVisible(false)
  }

  function abrirModal(p){
    setModalVisible(true);
    setPosicao(p);
  }



  return(
    <View style = {styles.container}>
<View style = {styles.navbar}>
      <View style={styles.voltar}   >
      <Pressable onPress ={() => navigation.navigate('Home')} >
      <Image style={styles.voltar}  source={require('../../../assets/voltar.png')}/>
      </Pressable>
      </View>
      <View>
      <Text style = {styles.menu}> Território 3 </Text>
       </View>
       <View>
      </View>
    
    </View>
    <View style={styles.column}>
       
        
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(0)} >
              <ImageBackground style={styles.elefante} source={require('../../../assets/Tamandua.jpg')}>
                <Text style={styles.negrit}> Tamandua </Text>
              </ImageBackground>
        </Pressable> 
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(1)} >
        <ImageBackground style={styles.elefante} source={require('../../../assets/raposa.jpg')}>
                <Text style={styles.negrit}> Coruja</Text>
              </ImageBackground>
        </Pressable> 
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(2)} >
        <ImageBackground style={styles.elefante} source={require('../../../assets/cachorro.jpg')}>
                <Text style={styles.negrit}> Cachorro do mato </Text>
              </ImageBackground>
        </Pressable> 
      </View>

       <Modal visible={modalVisible} animationType='fade' >
       
        <View style={{justifyContent:'center', alignItems:'center', flex:2, backgroundColor:"#0f0f0f"}}>
        
        <Image source={animais[posicao].imagem} style={{width:"100%", height:"70%"}}/>
        </View>
        <View style={{flex:3, paddingStart:15, backgroundColor:"#0f0f0f"}}>
        <Text style={styles.negrito}>Nome do animal</Text>
        <Text style={styles.normal}>{animais[posicao].nome}</Text>
        <Text style={styles.negrito}>Habitos</Text>
        <Text style={styles.normal}>{animais[posicao].habitos}</Text>
        <Text style={styles.negrito}>Reprodução</Text>
        <Text style={styles.normal}>{animais[posicao].reproducao}</Text>
        </View>
        <View style={{justifyContent:'center', alignItems:'center', backgroundColor:"#0f0f0f"}}>
        <Pressable onPress={()=>voltar()} >
        <Image style={styles.voltar}  source={require('../../../assets/voltar2.png')}/>
        </Pressable>
        </View>
      
      </Modal>
  
    </View>

     


  )  
}