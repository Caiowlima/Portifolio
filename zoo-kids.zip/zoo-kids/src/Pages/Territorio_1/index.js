import { useState } from 'react';
import { StyleSheet, Text, View, Image, ScrollView, Pressable, Modal, Button, ImageBackground} from 'react-native';
import styles from  './style';
import { useNavigation } from '@react-navigation/native';
export default function Home() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [posicao, setPosicao] = useState(0);

  const [animais, setPlanetas] = useState([
    {nome:"Elefante-Africano", 
    habitos:"Vivem em grupos liderados por fêmeas e percorrem grandes áreas em busca de água e comida." ,
    reproducao:"A gestação dura cerca de 22 meses, a mais longa entre os mamíferos, com nascimento de um único filhote.",
    imagem:require('../../../assets/Elefante.jpg')},
    {nome :"onca pintada", 
    habitos:'Solítaria e territorial, caça à noite e é ótima nadadora. Vive em florestas e áreas alagadas.',
    reproducao:" A fêmea cria sozinha os filhotes, que nascem após 3 a 4 meses de gestação, geralmente 1 a 4 filhotes.",
    imagem:require('../../../assets/onca.jpg')},
    {nome :"Flamingo", 
    habitos:"Vivem em grandes colônias em lagos rasos. Filtram a água para se alimentar de algas e pequenos crustáceos.",
    reproducao:"Constroem ninhos de barro e põem um único ovo. Ambos os pais cuidam do filhote.",
    imagem:require('../../../assets/flamingo.jpg')}
    
    
  ])

  function voltar(){
    setModalVisible(false)
  }

  function abrirModal(p){
    setModalVisible(true);
    setPosicao(p);
  }



  return(
    <View style = {styles.container}>
<View style = {styles.navbar}>
      <View style={styles.voltar}   >
      <Pressable onPress ={() => navigation.navigate('Home')} >
      <Image style={styles.voltar}  source={require('../../../assets/voltar.png')}/>
      </Pressable>
      </View>
      <View>
      <Text style = {styles.menu}> Território 1 </Text>
       </View>
       <View>
      </View>
    
    </View>
    <View style={styles.column}>
       
        
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(0)} >
              <ImageBackground style={styles.elefante} source={require('../../../assets/Elefante.jpg')}>
                <Text style={styles.negrit}> Elefante </Text>
              </ImageBackground>
        </Pressable> 
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(1)} >
        <ImageBackground style={styles.elefante} source={require('../../../assets/onca.jpg')}>
                <Text style={styles.negrit}> Onça Pintada </Text>
              </ImageBackground>
        </Pressable> 
      </View>
      <View style={styles.column}>
        <Pressable onPress={()=>abrirModal(2)} >
        <ImageBackground style={styles.elefante} source={require('../../../assets/flamingo.jpg')}>
                <Text style={styles.negrit}> flamingo </Text>
              </ImageBackground>
        </Pressable> 
      </View>

       <Modal visible={modalVisible} animationType='fade' >
       
        <View style={{justifyContent:'center', alignItems:'center', flex:2, backgroundColor:"#0f0f0f"}}>
        
        <Image source={animais[posicao].imagem} style={{width:"100%", height:"70%"}}/>
        </View>
        <View style={{flex:3, paddingStart:15, backgroundColor:"#0f0f0f"}}>
        <Text style={styles.negrito}>Nome do animal</Text>
        <Text style={styles.normal}>{animais[posicao].nome}</Text>
        <Text style={styles.negrito}>Habitos</Text>
        <Text style={styles.normal}>{animais[posicao].habitos}</Text>
        <Text style={styles.negrito}>Reprodução</Text>
        <Text style={styles.normal}>{animais[posicao].reproducao}</Text>
        </View>
        <View style={{justifyContent:'center', alignItems:'center', backgroundColor:"#0f0f0f"}}>
        <Pressable onPress={()=>voltar()} >
        <Image style={styles.voltar}  source={require('../../../assets/voltar2.png')}/>
        </Pressable>
        </View>
      
      </Modal>
  
    </View>

     


  )  
}