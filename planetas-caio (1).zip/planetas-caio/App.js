import { StatusBar } from 'expo-status-bar';
import { useState } from 'react';
import { StyleSheet, Text, View, Image, ScrollView, TouchableOpacity, Modal, Button} from 'react-native';

export default function App() {
  const [modalVisible, setModalVisible] = useState(false);
  const [posicao, setPosicao] = useState(0);

  const [planetas, setPlanetas] = useState([
    {nome:"Mercúrio", 
    Distancia: "46 - 69,8 milhões de km",
    duracaoDia:"176 dias terrestres" ,
    duracaoAno:"88 dias terrestres",
    temperatura:"400°C" ,
    diametro:"4879,4 KM",
    satelites: "Nenhum",
    imagem:require('./assets/mercurio.png')},
    {nome:"Vênus", 
    Distancia: "108 milhões de km",
    duracaoDia:"243 dias terrestres" ,
    duracaoAno:"224 dias terrestres",
    temperatura:"460}C" ,
    diametro:"12 103,6KM",
    satelites: "0",
    imagem:require('./assets/venus.png')},
    {nome:"Terra", 
    Distancia: "150 milhões de km",
    duracaoDia:"23 horas, 56 minutos e 04 segundos" ,
    duracaoAno:"365 dias e 6 horas",
    temperatura:"14ºC" ,
    diametro:"12 753,2 KM",
    satelites: "1",
    imagem:require('./assets/terra.png')},
    {nome:"Lua", 
    Distancia: "150 milhões de km",
    duracaoDia:"23 horas, 56 minutos e 04 segundos" ,
    duracaoAno:"365 dias e 6 horas",
    temperatura:"14ºC" ,
    diametro:"12 753,2 KM",
    satelites: "1",
    imagem:require('./assets/lua.png')},
    {nome:"Marte", 
    Distancia: "228 milhões de km",
    duracaoDia:"24 horas e 37 minutos" ,
    duracaoAno:"687 dias terrestres",
    temperatura:"-63ºC" ,
    diametro:"6792,4 KM",
    satelites: "2 ",
    imagem:require('./assets/marte.png')},
    {nome:"cinturão de asteroides", 
    Distancia: "350 milhões de km",
    diametro:"950 km (diâmetro)",
    satelites: "2 ",
    imagem:require('./assets/asteroides.png')},
    {nome:"Júpiter", 
    Distancia: "779 milhões de km",
    duracaoDia:"9 horas e 50 minutos" ,
    duracaoAno:"11,86 Anos terrestres",
    temperatura:"-108ºC" ,
    diametro:"142,984 KM",
    satelites: "79",
    imagem:require('./assets/jupiter.png')},
    {nome:"Saturno", 
    Distancia: "1.4 Bilhões de km",
    duracaoDia:"10 horas e 35 minutos" ,
    duracaoAno:"29,5 Anos terrestres",
    temperatura:"-139 ºC" ,
    diametro:"120536 KM",
    satelites: "82",
    imagem:require('./assets/saturno.png')},
    {nome:"Urano", 
    Distancia: "2,88 Bilhões de km",
    duracaoDia:"17 horas e 14 minutos" ,
    duracaoAno:"84 Anos terrestres",
    temperatura:"-220 ºC" ,
    diametro:"51118 KM",
    satelites: "27",
    imagem:require('./assets/urano.png')},
    {nome:"Netuno", 
    Distancia: "4,5 Bilhões de km",
    duracaoDia:"17" ,
    duracaoAno:"164,79 Anos terrestres",
    temperatura:"-220 ºC" ,
    diametro:"49528 KM",
    satelites: "14",
    imagem:require('./assets/netuno.png')}
  ])

  function voltar(){
    setModalVisible(false)
  }

  function abrirModal(p){
    setModalVisible(true);
    setPosicao(p);
  }



  return (
    <ScrollView >
            <StatusBar animated={true} backgroundColor="#000" style="light"/>
      <View style={styles.container}>
      <View style={styles.botao} >
        <Image source={require('./assets/sol.png')} style={styles.sol}/>
      </View>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(0)} >
        <Image source={require('./assets/mercurio.png')} style={styles.mercurio}/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(1)} >
        <Image source={require('./assets/venus.png')} style={styles.venus}/>
      </TouchableOpacity>
      <View style={styles.teste} >
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(2)}  >
        <Image source={require('./assets/terra.png')} style={styles.terra}/>
      </TouchableOpacity>
       <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(3)}  >
        <Image source={require('./assets/lua.png')} style={styles.lua}/>
      </TouchableOpacity>
      </View>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(4)}  >
        <Image source={require('./assets/marte.png')} style={styles.marte}/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(5)}  >
        <Image source={require('./assets/asteroides.png')} style={styles.asteroides}/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(6)} >
      <Image source={require('./assets/jupiter.png')} style={styles.jupiter}/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(7)} >
      <Image source={require('./assets/saturno.png')} style={styles.saturno}/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(8)} >
      <Image source={require('./assets/urano.png')} style={styles.urano}/>
      </TouchableOpacity>
      <TouchableOpacity style={styles.botao} onPress={()=>abrirModal(9)} >
      <Image source={require('./assets/netuno.png')} style={styles.netuno}/>
      </TouchableOpacity> 
      </View>






      <Modal visible={modalVisible} animationType='fade' >
        <View style={{justifyContent:'center', alignItems:'center', flex:2, backgroundColor:"#000"}}>
        <Text style={{fontSize:30, margin:10}}>Nosso Sistema Solar</Text>
        <Image source={planetas[posicao].imagem} style={{width:"70%", height:"90%"}}/>
        </View>
        <View style={{flex:3, paddingStart:15, backgroundColor:"#000"}}>
        <Text style={styles.negrito}>Nome Planeta</Text>
        <Text style={styles.normal}>{planetas[posicao].nome}</Text>
        <Text style={styles.negrito}>Duração do Dia</Text>
        <Text style={styles.normal}>{planetas[posicao].duracaoDia}</Text>
        <Text style={styles.negrito}>Duração do Ano</Text>
        <Text style={styles.normal}>{planetas[posicao].duracaoAno}</Text>
        <Text style={styles.negrito}>Temperatura</Text>
        <Text style={styles.normal}>{planetas[posicao].temperatura}</Text>
        <Text style={styles.negrito}>Diametro</Text>
        <Text style={styles.normal}>{planetas[posicao].diametro}</Text>
        <Text style={styles.negrito}>Satélite</Text>
        <Text style={styles.normal}>{planetas[posicao].satelites}</Text>
        </View>
        <View style={{justifyContent:'center', alignItems:'center', backgroundColor:"#000"}}>
        <Button title="voltar" onPress={()=>voltar()} />
        </View>
      </Modal>


    </ScrollView>   
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#000',
  },
  botao:{
    width:'100%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sol:{
    width:430,
    height:430,
  },
  mercurio:{
    width:100,
    height:100,
  },
  venus:{
    width:200,
    height:200,
  },
  teste:{
    flexDirection:'row',
    alignItems:'center',
    
    margin:50,
    width:150,
    height:150
  },
  terra:{

    width:220,
    height:220,
  },
  lua:{
    width:50,
    height:50,
  },
  marte:{
    width:150,
    height:150,
  },
  asteroides:{
    width:'100%',
    height:150,
  },
  jupiter:{
    width:400,
    height:400,
  },
  saturno:{
    width:450,
    height:450,
  },
  urano:{
    width:200,
    height:200,
  },
  netuno:{
    width:300,
    height:300,
  },

  negrito:{
  fontSize:15,
  fontWeight:'bold',
  color:"#fff",
  },
  normal:{
    fontSize:25,
    marginBottom:15,
    color:"#fff"
    }


});
