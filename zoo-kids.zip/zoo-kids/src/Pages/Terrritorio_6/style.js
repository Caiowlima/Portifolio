import { StyleSheet } from "react-native";

export default StyleSheet.create ({
    navbar:{
      
    backgroundColor:'#e8b866',
    justifyContent:'space-between',
    width:'100%',
    height:'10%',
    flexDirection:'row',
    alignItems:'flex-end',
 
    marginBottom:'30%',
  },
  menu:{
    fontWeight:'bold',
    width:100,
    height:50,
      fontSize:18,
  },
  voltar:{
    fontWeight:'bold',
    width:50,
    height:50,
    
  },
  
  container: {
    flex:1,
     backgroundColor:'#71bd89',
     
  },
  elefante:{
    
    display:'flex',
    width:'100%',
    height:120,
    justifyContent:'center',
    marginBottom:20,
   
  },
   negrit:{
     
     flexDirection:'row-reverse',
     display:'flex',
  fontSize:25,
  fontWeight:'bold',
  color:"#fff",
  },
  column:{
   diplay:'flex',
    margin:'15px',
    width:'100%',
    justifyContent:'center'
  },
  botao:{
borderWidth:2
  },
  normal:{
    fontSize:20,
    marginBottom:15,
    color:"#fff"
    },

    negrito:{
     
  fontSize:25,
  fontWeight:'bold',
  color:"#fff",
  },

})