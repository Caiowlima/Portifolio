import { StyleSheet } from "react-native";

export default StyleSheet.create ({
  navbar:{
    backgroundColor:'#e8b866',
    justifyContent:'space-between',
    width:'100%',
    height:'10%',
    flexDirection:'row',
    alignItems:'flex-end',
 
    marginBottom:'30%',
  },
  menu:{
    fontWeight:'bold',
    width:50,
    height:50,
  fontSize:18,
    
  },
  
  container: {
    flex:1,
     backgroundColor:'#71bd89',
     
  },
  
  fundo:{
   borderRadius: 25,
    width:100,
    height:100,
     alignItems:'center',
  },
  terri:{
     margin:'20px',

    width:100,
    height:110,
     alignItems:'center',
  },
  linha:{
    borderRadius: 15,
    margin:50,
    width:100,
   
    flexDirection:'row',
    justifyContent:'space-around',
  },
  row:{
  
   marginBottom:15,
    width:'100%',
    flexDirection:'row',
    justifyContent:'space-around',
  },
  texto:{
    margin:5,
    fontSize:20,
  fontWeight:'bold',
  color:"#fff",
    
  },
  voltar:{
    fontWeight:'bold',
    width:50,
    height:50,
    
  },
  

})