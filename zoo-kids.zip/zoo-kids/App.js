import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';


import Home from './src/Pages/Home';
import Territorio_1 from './src/Pages/Territorio_1';
import Territorio_2 from './src/Pages/Territorio_2';
import Territorio_3 from './src/Pages/Territorio_3';
import Territorio_4 from './src/Pages/Terrritorio_4';
import Territorio_5 from './src/Pages/Terrritorio_5';
import Territorio_6 from './src/Pages/Terrritorio_6';


const Stack = createNativeStackNavigator () ;

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component= {Home}
        options={{
          title:"Menu",
          headerstyle:{backgroundColor: "#FFDEAD"},
          headerTintColor:"black",
          headerTitleAlign:'center',
          headerShown:false,
          
        }}
        />
        <Stack.Screen name="Territorio_1" component= {Territorio_1}
        options={{
          title:"1º Território",
          headerstyle:{backgroundColor: "#FFDEAD"},
          headerTintColor:"black",
          headerTitleAlign:'center',
           headerShown:false,
          
        }}
        />
        <Stack.Screen name="Territorio_2" component= {Territorio_2}
          options={{
           headerShown:false,
        }}
        />
        <Stack.Screen name="Territorio_3" component= {Territorio_3}  options={{
           headerShown:false,
        }}
        />
        <Stack.Screen name="Territorio_4" component= {Territorio_4}  options={{
           headerShown:false,
        }}
        />
        <Stack.Screen name="Territorio_5" component= {Territorio_5}  options={{
           headerShown:false,
        }}
        />
        <Stack.Screen name="Territorio_6" component= {Territorio_6}  options={{
           headerShown:false,
        }}
        />
      </Stack.Navigator>
    </NavigationContainer>
   
   
  );
}
