import { StyleSheet, Text, View, Image, ScrollView, Pressable, Modal, Button, ImageBackground} from 'react-native';
import styles from  './style';
import { useNavigation } from '@react-navigation/native';
import { useState } from 'react';
export default function Home() {
  const navigation = useNavigation();
  const [modalVisible, setModalVisible] = useState(false);
  const [posicao, setPosicao] = useState(0);

  const [animais, setPlanetas] = useState([
    {nome:"Elefante-Africano", 
    habitos:"Vivem em grupos liderados por fêmeas e percorrem grandes áreas em busca de água e comida." ,
    },
    
  ])

  function voltar(){
    setModalVisible(false)
  }

  function abrirModal(p){
    setModalVisible(true);
    setPosicao(p);
  }

  return(
    <View style = {styles.container}>
    <View style = {styles.navbar}>
      <View style = {styles.menu}>
      </View>
      <View>
      <Text style = {styles.menu}> Menu </Text>
       </View>
       <View>
      <Pressable onPress={()=>abrirModal(0)} >
      <Image style={styles.menu}  source={require('../../../assets/menu.png')}/>
      </Pressable>
      </View>
    
    <Modal visible={modalVisible} animationType='fade' >
       
        <View style={{flex:3, paddingStart:15,}}>
        <Text style={styles.negrito}>Nome do animal</Text>
        <Text style={styles.normal}>{animais[posicao].nome}</Text>
        <Text style={styles.negrito}>Habitos</Text>
        <Text style={styles.normal}>{animais[posicao].habitos}</Text>
        <Text style={styles.negrito}>Reprodução</Text>
        <Text style={styles.normal}>{animais[posicao].reproducao}</Text>
        </View>
        <View style={{justifyContent:'center', alignItems:'center', }}>
        <Pressable onPress={()=>voltar()} >
        <Image style={styles.voltar}  source={require('../../../assets/voltar.png')}/>
        </Pressable>
        </View>
      
      </Modal>

    </View>
    
     <View style={styles.row}>
        <Pressable onPress ={() => navigation.navigate('Territorio_1')} >
                <Image style={styles.terri}  source={require('../../../assets/tiger-desenho.png')}/>
                <Text style={styles.texto}> Território 1 </Text>
                </Pressable>       
        <Pressable onPress ={() => navigation.navigate('Territorio_2')} >
          <Image style={styles.terri}  source={require('../../../assets/arara-desenho.png')}/>
          <Text style={styles.texto}> Território 2 </Text>
        </Pressable>
         </View>
        <View style={styles.row}>
        <Pressable onPress ={() => navigation.navigate('Territorio_3')} >
              
                <Image style={styles.terri}  source={require('../../../assets/bicho-desenho.png')}/>
               
                   <Text style={styles.texto}> Território 3 </Text> 
        </Pressable>
        <Pressable onPress ={() => navigation.navigate('Territorio_4')} >
      
          <Image style={styles.terri}  source={require('../../../assets/leao-desenho.png')}/>
        
          <Text style={styles.texto}> Território 4 </Text>
        </Pressable>
      </View>
      <View style={styles.row}>
        <Pressable onPress ={() => navigation.navigate('Territorio_5')} >
          
                <Image style={styles.terri}  source={require('../../../assets/chimpanze-desenho.png')}/>
             
              <Text style={styles.texto}> Território 5 </Text>
        </Pressable>
        <Pressable onPress ={() => navigation.navigate('Territorio_6')} >
        
          <Image style={styles.terri}  source={require('../../../assets/zebra-desenho.png')}/>
         
          <Text style={styles.texto}> Território 6 </Text>
        </Pressable>
      </View>
     
     
    </View>


  )  
}